// Name: Sara Al-Hachami
// Project 1 for Data Structures (CIS 2353)
// Summer 2025
// Project: Calculating Heart Rates

// Class to store and manage birthdate information
public class DateOfBirth {
    private int birthMonth;
    private int birthDay;
    private int birthYear;

    // Default constructor - assigns a preset birthday
    public DateOfBirth() {
        this.birthMonth = 8;
        this.birthDay = 19;
        this.birthYear = 2002;
    }

    // Constructor with specific month, day, and year values
    public DateOfBirth(int birthMonth, int birthDay, int birthYear) {
        this.birthMonth = birthMonth;
        this.birthDay = birthDay;
        this.birthYear = birthYear;
    }

    // Getter and setter for birth month
    public int getBirthMonth() { return birthMonth; }
    public void setBirthMonth(int birthMonth) { this.birthMonth = birthMonth; }

    // Getter and setter for birth day
    public int getBirthDay() { return birthDay; }
    public void setBirthDay(int birthDay) { this.birthDay = birthDay; }

    // Getter and setter for birth year
    public int getBirthYear() { return birthYear; }
    public void setBirthYear(int birthYear) { this.birthYear = birthYear; }

    // Returns the full date in MM/DD/YYYY format
    public String getFullDate() {
        return birthMonth + "/" + birthDay + "/" + birthYear;
    }
}
