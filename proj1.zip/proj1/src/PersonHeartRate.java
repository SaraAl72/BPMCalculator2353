// Name: Sara Al-Hachami
// Project 1 for Data Structures (CIS 2353)
// Summer 2025
// Project: Calculating Heart Rates

import java.time.LocalDate;
import java.time.Period;

// Class to store person's name and their birth info and calculate heart rates
public class PersonHeartRate {
    private String firstName;
    private String lastName;
    private DateOfBirth birthDate;

    // Constructor to initialize name and birth date
    public PersonHeartRate(String firstName, String lastName, DateOfBirth birthDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
    }

    // Getters and setters for first and last name
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    // Getter and setter for birth date
    public DateOfBirth getBirthDate() { return birthDate; }
    public void setBirthDate(DateOfBirth birthDate) { this.birthDate = birthDate; }

    // Calculates the person's age using today's date
    public int calculateAge() {
        LocalDate today = LocalDate.now();
        LocalDate dob = LocalDate.of(
                birthDate.getBirthYear(),
                birthDate.getBirthMonth(),
                birthDate.getBirthDay()
        );
        Period period = Period.between(dob, today);
        return period.getYears();
    }

    // Calculates maximum heart rate using formula 220 - age
    public int getMaxHeartRate() {
        return 220 - calculateAge();
    }

    // Calculates target heart rate range (50% to 85% of max heart rate)
    public String getTargetHeartRateRange() {
        int max = getMaxHeartRate();
        int lower = (int)(max * 0.5);
        int upper = (int)(max * 0.85);
        return lower + " - " + upper;
    }

    // Outputs the user's name, birthdate, max heart rate, and target BPM
    public void printData() {
        System.out.println(lastName + ", " + firstName);
        System.out.println("DOB: " + birthDate.getFullDate());
        System.out.println("Max heart rate you can have : " + getMaxHeartRate() + " bpm");
        System.out.println("Target BPM range: " + getTargetHeartRateRange() + " bpm");
    }
}