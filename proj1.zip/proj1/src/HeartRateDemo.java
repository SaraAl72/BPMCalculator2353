// Name: Sara Al-Hachami
// Project 1 for Data Structures (CIS 2353)
// Summer 2025
// Project: Calculating Heart Rates


import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

// Main class to drive the heart rate calculator demo
public class HeartRateDemo {
    // Helper method for prompting user input with a message
    public static String getInput(Scanner input, String message) {
        System.out.print(message);
        return input.nextLine();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<PersonHeartRate> heartRateList = new ArrayList<>(); // stores people

        boolean morePeople = true;

        // Repeatedly ask user to enter people until they say no
        while (morePeople) {
            System.out.println("Please enter the information needed to do the following calculations");

            String firstName = getInput(input, "What’s the first name? ");
            String lastName = getInput(input, "What’s the last name? ");

            int month, day, year;
            while (true) {
                System.out.print("Birth month : ");
                month = input.nextInt();

                System.out.print("Birth day: ");
                day = input.nextInt();

                System.out.print("Birth year: ");
                year = input.nextInt();
                input.nextLine(); // consume newline

                try {
                    LocalDate checkDate = LocalDate.of(year, month, day); // verifies valid date
                    break; // valid
                } catch (DateTimeException e) {
                    System.out.println("Oops! That date is not valid. Please try again.\n");
                }
            }

            // Create objects and add to list
            DateOfBirth birthDate = new DateOfBirth(month, day, year);
            PersonHeartRate person = new PersonHeartRate(firstName, lastName, birthDate);

            // Trim and reassign all info (precautionary)
            person.setFirstName(person.getFirstName().trim());
            person.setLastName(person.getLastName().trim());

            int birthMonth = person.getBirthDate().getBirthMonth();
            int birthDay = person.getBirthDate().getBirthDay();
            int birthYear = person.getBirthDate().getBirthYear();

            person.getBirthDate().setBirthMonth(birthMonth);
            person.getBirthDate().setBirthDay(birthDay);
            person.getBirthDate().setBirthYear(birthYear);

            person.setBirthDate(person.getBirthDate());
            heartRateList.add(person);

            // Ask if user wants to continue
            String answer = getInput(input, "Add another person? yes or no : ").toLowerCase();
            if (!answer.equals("yes")) {
                morePeople = false;
            }
        }

        // Print all info for each person
        System.out.println();
        for (PersonHeartRate p : heartRateList) {
            p.printData();
        }

        // Final message with a personal health note
        System.out.println("\nThanks for using my Heart Rate Calculator! :) Fun Fact: Lately there has been a rise in a condition called supraventricular tachycardia (SVT for short). This condition is where the heart beats at an abnormal speed between 150-220 beats for minute. I myself have this condition");
        input.close();
    }
}
